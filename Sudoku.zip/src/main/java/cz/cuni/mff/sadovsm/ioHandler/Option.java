package cz.cuni.mff.sadovsm.ioHandler;

public enum Option {
    RESTART, SOLVE, QUIT, HELP, NONE, FILL, POSSIBLE, HINT, UNDO, AUTO
}
